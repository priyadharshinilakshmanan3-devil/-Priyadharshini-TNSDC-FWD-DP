// Smooth scroll for sidebar links
document.querySelectorAll('.sidebar a').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    window.scrollTo({
      top: target.offsetTop - 20,
      behavior: 'smooth'
    });
  });
});

// Highlight active section in sidebar
const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll(".sidebar a");

window.addEventListener("scroll", () => {
  let current = "";
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 60;
    if (pageYOffset >= sectionTop) {
      current = section.getAttribute("id");
    }
  });
  navLinks.forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + current) {
      link.classList.add("active");
    }
  });
});

// Contact form alert
document.getElementById("contactForm").addEventListener("submit", function(e){
  e.preventDefault();
  const name = this.querySelector("input[type='text']").value;
  alert("Thank you, " + name + "! Your message has been sent.");
  this.reset();
});